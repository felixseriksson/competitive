flag = b"REDACTEDREDACTEDREDACTEDREDACTED"
password = b"redactedredactedredactedredacted"